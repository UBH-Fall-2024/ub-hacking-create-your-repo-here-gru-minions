from tkinter import * # For all GUI Elements in our code
import webbrowser # For all Links in our code

# Initiates Main Screen
window=Tk()
window.title("Balance In Wonderland")
window.geometry('400x600')

# GENERAL FUNCTIONS

# Hides specified screen's contents
def hideScreen(screen):
    if (screen=='h'):
        h_bgImage_label.place_forget()
        h_title_label.place_forget()
        h_streak_label.place_forget()
        h_streak_text.place_forget()
        h_toSupport_button.place_forget()
        h_toPhysical_button.place_forget()
        h_toChecklist_button.place_forget()
        h_toMental_button.place_forget()
        h_toSettings_button.place_forget()
        h_feedback_textbox.place_forget()
        h_charImage_label.place_forget()
    if (screen=='sup'):
        sup_bgImage_label.place_forget()
        sup_title_label.place_forget()
        sup_toHome_button.place_forget()
        sup_toSettings_button.place_forget()
        sup_supports_listbox.place_forget()
        sup_add_button.place_forget()
    if (screen=='p'):
        p_bgImage_label.place_forget()

        #Top bar
        p_toHome_button.place_forget()
        p_title_label.place_forget()
        p_toSettings_button.place_forget()

        #Widget
        p_widget_label.place_forget()
        p_calories_label.place_forget()
        for i in range(len(p_calories_bars)):
                p_calories_bars[i].place_forget()
        p_vert_bar.place_forget()
        p_hori_bar.place_forget()
        p_max_numg.place_forget()
        p_mid_numg.place_forget()
        p_days_label.place_forget()

        # Recommendations
        p_rec_label1.place_forget()
        p_rec_label2.place_forget()
        p_rec_label3.place_forget()
        p_recImage1_label.place_forget()
        p_recImage2_label.place_forget()
        p_recImage3_label.place_forget()
        p_rec_text1.place_forget()
        p_rec_text2.place_forget()
        p_rec_text3.place_forget()
        p_rec_desc1.place_forget()
        p_rec_desc2.place_forget()
        p_rec_desc3.place_forget()
        p_rec_button1.place_forget()
        p_rec_button2.place_forget()
        p_rec_button3.place_forget()
    if (screen=='c'):
        c_bgImage_label.place_forget()
        c_title_label.place_forget()
        c_toHome_button.place_forget()
        c_toSettings_button.place_forget()
        c_incomp_label.place_forget()
        c_incomp_listbox.place_forget()
        c_comp_label.place_forget()
        c_comp_listbox.place_forget()
    if (screen=='m'):
        m_bgImage_label.place_forget()

        #Top bar
        m_toHome_button.place_forget()
        m_title_label.place_forget()
        m_toSettings_button.place_forget()

        #Widget
        m_widget_label.place_forget()
        m_hrs_label.place_forget()
        for i in range(len(m_hrs_bars)):
                m_hrs_bars[i].place_forget()
        m_vert_bar.place_forget()
        m_hori_bar.place_forget()
        m_max_numg.place_forget()
        m_mid_numg.place_forget()
        m_days_label.place_forget()

        # Recommendations
        m_rec_label1.place_forget()
        m_rec_label2.place_forget()
        m_rec_label3.place_forget()
        m_recImage1_label.place_forget()
        m_recImage2_label.place_forget()
        m_recImage3_label.place_forget()
        m_rec_text1.place_forget()
        m_rec_text2.place_forget()
        m_rec_text3.place_forget()
        m_rec_desc1.place_forget()
        m_rec_desc2.place_forget()
        m_rec_desc3.place_forget()
        m_rec_button1.place_forget()
        m_rec_button2.place_forget()
        m_rec_button3.place_forget()
    if (screen=='set'):
        set_bgImage_label.place_forget()
        set_title_label.place_forget()
        set_toHome_button.place_forget()
        set_age_label.place_forget()
        set_age_dropdown.place_forget()
        set_gender_label.place_forget()
        set_gender_dropdown.place_forget()
        set_height_label.place_forget()
        set_height_dropdown.place_forget()
        set_weight_label.place_forget()
        set_weight_dropdown.place_forget()
        set_difficulty_label.place_forget()
        set_difficulty_dropdown.place_forget()

# Shows specified screen's contents
def showScreen(screen):
    if (screen=='h'):
        h_bgImage_label.place(x=0,y=0)
        h_title_label.place(x=50,y=0,width=300,height=50)
        h_streak_label.place(x=400,y=0,anchor='ne',width=50,height=50)
        h_streak_text.place(x=375,y=25,anchor='w',width=20,height=25)
        h_toSupport_button.place(width=80,height=80,x=0,y=560)
        h_toPhysical_button.place(width=80,height=80,x=80,y=560)
        h_toChecklist_button.place(width=80,height=80,x=160,y=560)
        h_toMental_button.place(width=80,height=80,x=240,y=560)
        h_toSettings_button.place(width=80,height=80,x=320,y=560)
        h_feedback_textbox.place(x=75,y=410,width=250,height=100)
        h_charImage_label.place(x=75,y=75,width=250,height=325)
    if (screen=='sup'):
        sup_bgImage_label.place(x=0,y=0)
        sup_title_label.place(x=50,y=0,width=300,height=50)
        sup_toHome_button.place(x=0,y=0,width=50,height=50)
        sup_toSettings_button.place(x=350,y=0,width=50,height=50)
        sup_supports_listbox.place(x=25,y=50,width=350,height=450)
        sup_add_button.place(x=200,y=500,width=100,height=100,anchor='n')
    if (screen=='p'):
        p_bgImage_label.place(x=0,y=0)
        p_toHome_button.place(x=0,y=0,width=50,height=50)
        p_title_label.place(x=50,y=0,width=300,height=50)
        p_toSettings_button.place(x=350,y=0,width=50,height=50)
        p_widget_label.place(x=50,y=80,width=300,height=150)
        p_calories_label.place(x=55,y=85,width=60,height=14)
        for i in range(len(p_calories_bars)):
            if(p_calories_vals[i] != 0):
                p_calories_bars[i].place(x=122+33*i,y=200,anchor='s',width=20,height=int(p_calories_vals[i]/max(p_calories_vals)*95))
        p_vert_bar.place(x=84,y=200,anchor='sw',width=2,height=95)
        p_hori_bar.place(x=84,y=200,anchor='sw',width=260,height=2)
        p_max_numg.place(x=84,y=105,anchor='ne')
        p_max_numg.config(text=findMaxCal())
        p_mid_numg.place(x=84,y=152,anchor='ne')
        p_mid_numg.config(text=str(int(findMaxCal())//2))
        p_days_label.place(x=105,y=205,width=235,height=16)
        p_rec_label1.place(y=260,width=400,height=110)
        p_rec_label2.place(y=370,width=400,height=110)
        p_rec_label3.place(y=480,width=400,height=110)
        p_recImage1_label.place(x=20,y=280,width=70,height=70)
        p_recImage2_label.place(x=20,y=390,width=70,height=70)
        p_recImage3_label.place(x=20,y=500,width=70,height=70)
        p_rec_text1.place(x=115,y=280,width=225,height=22)
        p_rec_text2.place(x=115,y=390,width=225,height=22)
        p_rec_text3.place(x=115,y=500,width=225,height=22)
        p_rec_desc1.place(x=115,y=305,width=225,height=44)
        p_rec_desc2.place(x=115,y=415,width=225,height=44)
        p_rec_desc3.place(x=115,y=525,width=225,height=44)
        p_rec_button1.place(x=390,y=305,width=20,height=20,anchor='ne')
        p_rec_button2.place(x=390,y=415,width=20,height=20,anchor='ne')
        p_rec_button3.place(x=390,y=525,width=20,height=20,anchor='ne')
    if (screen=='c'):
        c_bgImage_label.place(x=0,y=0)
        c_title_label.place(x=50,y=0,width=300,height=50)
        c_toHome_button.place(x=0,y=0,width=50,height=50)
        c_toSettings_button.place(x=350,y=0,width=50,height=50)
        c_incomp_label.place(x=0,y=50,width=400,height=50)
        c_incomp_listbox.place(x=0,y=100,width=400,height=280)
        c_comp_label.place(x=0,y=380,width=400,height=50)
        c_comp_listbox.place(x=0, y=430, width = 400, height=180)
    if (screen=='m'):
        m_bgImage_label.place(x=0,y=0)
        m_toHome_button.place(x=0,y=0,width=50,height=50)
        m_title_label.place(x=50,y=0,width=300,height=50)
        m_toSettings_button.place(x=350,y=0,width=50,height=50)
        m_widget_label.place(x=50,y=80,width=300,height=150)
        m_hrs_label.place(x=55,y=85,width=95,height=24)
        for i in range(len(m_hrs_bars)):
            if(m_hrs_vals[i] != 0):
                m_hrs_bars[i].place(x=122+33*i,y=200,anchor='s',width=20,height=int(m_hrs_vals[i]/max(m_hrs_vals)*95))
        m_vert_bar.place(x=84,y=200,anchor='sw',width=2,height=95)
        m_hori_bar.place(x=84,y=200,anchor='sw',width=260,height=2)
        m_max_numg.place(x=84,y=105,anchor='ne')
        m_max_numg.config(text=findMaxHr())
        m_mid_numg.place(x=84,y=152,anchor='ne')
        m_mid_numg.config(text=str(int(findMaxHr())//2))
        m_days_label.place(x=105,y=205,width=235,height=16)
        m_rec_label1.place(y=260,width=400,height=110)
        m_rec_label2.place(y=370,width=400,height=110)
        m_rec_label3.place(y=480,width=400,height=110)
        m_recImage1_label.place(x=20,y=280,width=70,height=70)
        m_recImage2_label.place(x=20,y=390,width=70,height=70)
        m_recImage3_label.place(x=20,y=500,width=70,height=70)
        m_rec_text1.place(x=115,y=280,width=225,height=22)
        m_rec_text2.place(x=115,y=390,width=225,height=22)
        m_rec_text3.place(x=115,y=500,width=225,height=22)
        m_rec_desc1.place(x=115,y=305,width=225,height=44)
        m_rec_desc2.place(x=115,y=415,width=225,height=44)
        m_rec_desc3.place(x=115,y=525,width=225,height=44)
        m_rec_button1.place(x=390,y=305,width=20,height=20,anchor='ne')
        m_rec_button2.place(x=390,y=415,width=20,height=20,anchor='ne')
        m_rec_button3.place(x=390,y=525,width=20,height=20,anchor='ne')
    if (screen=='set'):
        set_bgImage_label.place(x=0,y=0)
        set_title_label.place(x=50,y=0,width=300,height=50)
        set_toHome_button.place(x=0,y=0,width=50,height=50)
        set_age_label.place(x=50,y=100,width=150,height=50)
        set_age_dropdown.place(x=200,y=100,width=150,height=50)
        set_gender_label.place(x=50,y=200,width=150,height=50)
        set_gender_dropdown.place(x=200,y=200,width=150,height=50)
        set_height_label.place(x=50,y=300,width=150,height=50)
        set_height_dropdown.place(x=200,y=300,width=150,height=50)
        set_weight_label.place(x=50,y=400,width=150,height=50)
        set_weight_dropdown.place(x=200,y=400,width=150,height=50)
        set_difficulty_label.place(x=50,y=500,width=150,height=50)
        set_difficulty_dropdown.place(x=200,y=500,width=150,height=50)

# Switches from current screen to new sceen            
def switchScreen(currentScreen,newScreen):
    hideScreen(currentScreen)
    showScreen(newScreen)

# Opens link based on spec, the specified keyword
def extLink(spec):
    if (spec == "TripleS"): # B)
        webbrowser.open("https://www.youtube.com/@triplescosmos/videos")
    if (spec == 'pRun'):
        webbrowser.open('https://www.youtube.com/watch?v=wJxTJP-Z4s0')
    if (spec == 'pGym'):
        webbrowser.open('https://www.nerdfitness.com/blog/a-beginners-guide-to-the-gym-everything-you-need-to-know/')
    if (spec == 'pDrink'):
        webbrowser.open('https://www.mayoclinic.org/healthy-lifestyle/nutrition-and-healthy-eating/in-depth/water/art-20044256')
    if (spec == 'mSleep'):
        webbrowser.open("https://www.sleepfoundation.org/how-sleep-works/why-do-we-need-sleep")
    if (spec == 'mMed'):
        webbrowser.open("https://www.healthline.com/nutrition/12-benefits-of-meditation")
    if (spec == 'mTalk'):
        webbrowser.open("https://www.piedmont.org/living-real-change/4-reasons-friends-and-family-are-good-for-your-health")
        

# HOME SCREEN FUNCTIONS

# Each hovered/unhovered pair for the buttons at the bottom of home screen
def hoveredSup(event):
    h_toSupport_button.place(y=520)
def unhoveredSup(event):
    h_toSupport_button.place(y=560)
def hoveredP(event):
    h_toPhysical_button.place(y=520)
def unhoveredP(event):
    h_toPhysical_button.place(y=560)
def hoveredC(event):
    h_toChecklist_button.place(y=520)
def unhoveredC(event):
    h_toChecklist_button.place(y=560)
def hoveredM(event):
    h_toMental_button.place(y=520)
def unhoveredM(event):
    h_toMental_button.place(y=560)
def hoveredSet(event):
    h_toSettings_button.place(y=520)
def unhoveredSet(event):
    h_toSettings_button.place(y=560)


# Updates feedback visual and text based on proportion of tasks completed
def updateFeedback():
    global h_feedback_text, h_charImage
    percentageComplete=round(com_num/(com_num+incom_num),2)
    if(percentageComplete==0):
        h_feedback_text="C'mon! Let’s get started before you fall down\na rabbit hole!"
        h_charImage=PhotoImage(file="biw_alice1.png")
    elif(percentageComplete<=.33):
        h_feedback_text="Watch out! Keep going or you might shrink!"
        h_charImage=PhotoImage(file="biw_alice2.png")
    elif(percentageComplete<=.66):
        h_feedback_text="Keep going, you have to\nescape the Mad Hatter’s chaotic tea party!"
        h_charImage=PhotoImage(file="biw_alice3.png")
    elif(percentageComplete<=.99):
        h_feedback_text="Almost there, but don’t\nfall for the Cheshire\nCat’s wild antics!"
        h_charImage=PhotoImage(file="biw_alice4.png")
    else:
        h_feedback_text="NICE JOB! You finally\ndefeated the Queen of Hearts!"
        h_charImage=PhotoImage(file="biw_alice5.png")
    h_feedback_textbox.config(state=NORMAL)
    h_feedback_textbox.delete("1.0", END)
    h_feedback_textbox.insert("1.0", h_feedback_text)
    h_feedback_textbox.config(state=DISABLED)
    h_charImage_label.config(image=h_charImage)

# SUPPORT SCREEN FUNCTIONS

# Generates Random People
def randomGenerateContacts():
    contacts={'Joe':'(716)253-7545','Kelly':'(716)734-1279','Rick':'(716)354-0965'}
    names=list(contacts.keys())
    for i in range(len(names)):
        sup_supports_listbox.insert(i,f'Name: {names[i]} Phone Number: {contacts[names[i]]} >')

# "Calls" contact you clicked on (we are NOT calling them :fire: :fire:)
def call(action):
    popUp = Toplevel()
    popUp.title("Call")
    popUp.geometry("300x200")
    selected_index = sup_supports_listbox.curselection()
    if selected_index:
        phone_num = sup_supports_listbox.get(selected_index)[-15:-1]

    phone = Label(popUp,text=f"Phone Number: {phone_num}",font=("Comic Sans MS",12))
    phone.pack()
    call_Button = Button(popUp,text="CALL",command=popUp.destroy)
    call_Button.place(x=100,y=80,width=100,height=50)

# Adds another contact to the Supports list
def addContact(action):
    def add():
        name = line1.get()
        phone_number = line2.get()
        info = "Name: " + name + " Phone Number: " + phone_number + " >"
        sup_supports_listbox.insert(END, info)
        popUp.destroy()
   
    popUp = Toplevel()
    popUp.title("Add")
    popUp.geometry("300x200")
    title = Label(popUp,text="Add Contact",font=("Comic Sans MS",12))
    title.place(x=100,y=10)
    Label(popUp, text='Name').place(x=50,y=50,width=50,height=50)
    Label(popUp, text='Phone Number').place(x=50,y=100,width=80,height=50)
    line1 = Entry(popUp)
    line2 = Entry(popUp)
   
    line1.place(x=150,y=65,width=100,height=20)
    line2.place(x=150,y=115,width=100,height=20)
    submit_button = Button(popUp,text="Submit",command=lambda:add())
    submit_button.place(x=110,y=150,width=70,height=30)

# CHECKLIST SCREEN FUNCTIONS

# Generates tasks
def generateTasks():
    # weight, height, age, male/female
    # "10-19","20-29","30-39","40-49","50-59","60+"
    incom_tasklist.clear()
    dist=0
    calories=0
    breathe=0
    if (set_age == '10-19'):
        dist,calories,breathe='20-30','2000-2500','5-10'
        if (set_difficulty=='easy'): dist='15-25'
        elif (set_difficulty=='hard'): dist='25-35'
    elif (set_age =='20-29'):
        dist,calories,breathe='30-40','2200-2800','10-15'
        if (set_difficulty=='easy'): dist='20-30'
        elif (set_difficulty=='hard'): dist='45-60'
    elif (set_age =='30-39'):   
        dist,calories,breathe='25-35','2200-2800','10-15'
        if (set_difficulty=='easy'): dist='20-30'
        elif (set_difficulty=='hard'): dist='30-40'
    elif (set_age =='40-49'):
        dist,calories,breathe='20-30','2000-2600','10-20'
        if (set_difficulty=='easy'): dist='15-20'
        elif (set_difficulty=='hard'): dist='30-40'
    elif (set_age =='50-59'):
        dist,calories,breathe='15-20','1800-2400','15-20'
        if (set_difficulty=='easy'): dist='10-15'
        elif (set_difficulty=='hard'): dist='20-25'
    else:
        dist,calories,breathe='10-15','1600-2200','15-20'
        if (set_difficulty=='easy'): dist='5-15'
        elif (set_difficulty=='hard'): dist='10-20'

    incom_tasklist.append(f"◻    Jog for {dist} minutes")
    incom_tasklist.append(f"◻    Eat {calories} calories")
    incom_tasklist.append(f"◻    Mediate for {breathe} minutes")    
    c_incomp_listbox.delete(0, END)
    c_comp_listbox.delete(0, END)
    for i in range(len(incom_tasklist)):
        c_incomp_listbox.insert(i,incom_tasklist[i])


# Updates number of incomplete/complete tasks
def updateLists():
    global incom_num,com_num
    incom_num=c_incomp_listbox.size()
    com_num=c_comp_listbox.size()
    updateFeedback()

# Sends a task to the Completed list
def completeTask(action):
    taskPosition = c_incomp_listbox.nearest(action.y)
    if taskPosition >= 0:
        comp_task = c_incomp_listbox.get(taskPosition)
        comp_task = "🗹" + comp_task[1:]
        c_incomp_listbox.delete(taskPosition)
        c_comp_listbox.insert(END,comp_task)
    updateLists()

# Sends a task to the Incomplete list
def undoTask(action):
    taskPosition = c_comp_listbox.nearest(action.y)
    if taskPosition >= 0:
        undo_task = c_comp_listbox.get(taskPosition)
        undo_task = "◻" + undo_task[1:]
        c_comp_listbox.delete(taskPosition)
        c_incomp_listbox.insert(c_incomp_listbox.size(),undo_task)
    updateLists()

# SETTINGS SCREEN FUNCTIONS

# Collects all the settings information by user
def updateSettings(*args):
    global set_age, set_gender, set_height, set_weight, set_difficulty
    set_age=set_age_variable.get()
    set_gender=set_gender_variable.get()
    set_height=set_height_variable.get()
    set_weight=set_weight_variable.get()
    set_difficulty=set_difficulty_variable.get()
    generateTasks()

# PHYSICAL HEALTH FUNCTIONS

# Stringing the highest number of calories
def findMaxCal():
    return str(max(p_calories_vals))

# MENTAL HEALTH FUNCTIONS

# Stringing the most number of hours slept
def findMaxHr():
    return str(max(m_hrs_vals))

# GLOBAL VARIABLES

incom_tasklist=[]
com_num=0
incom_num=0
contacts={}
h_feedback_text=""
h_charImage=PhotoImage(file="biw_alice1.png")
set_age=""
set_gender=""
set_height=""
set_weight=""
set_difficulty=""
home_icon=PhotoImage(file="biw_home_icon.png")
settings_icon=PhotoImage(file="biw_settings_icon.png")
h_support_icon=PhotoImage(file="biw_h_support_icon.png")
h_physical_icon=PhotoImage(file="biw_h_physical_icon.png")
h_checklist_icon=PhotoImage(file="biw_h_checklist_icon.png")
h_mental_icon=PhotoImage(file="biw_h_mental_icon.png")
h_settings_icon=PhotoImage(file="biw_h_settings_icon.png")


# HOME SCREEN VARIABLES

h_bgImage=PhotoImage(file='biw_home.png')
h_bgImage_label=Label(window,image=h_bgImage)
h_title_label=Label(window,text='Balance in Wonderland',borderwidth=2,relief="ridge",font=("Comic Sans MS",20))
h_streak_image=PhotoImage(file='biw_streaks.png')
h_streak_label=Label(window,image=h_streak_image)
h_streak_text=Label(window,font=("Comic Sans MS",20),text=0,bg='#2e1e02',fg='white')
h_toSupport_button=Button(window,command=lambda:switchScreen('h','sup'),image=h_support_icon)
h_toSupport_button.bind('<Enter>',hoveredSup)
h_toSupport_button.bind('<Leave>',unhoveredSup)
h_toPhysical_button=Button(window,command=lambda:switchScreen('h','p'),image=h_physical_icon)
h_toPhysical_button.bind('<Enter>',hoveredP)
h_toPhysical_button.bind('<Leave>',unhoveredP)
h_toChecklist_button=Button(window,command=lambda:switchScreen('h','c'),image=h_checklist_icon)
h_toChecklist_button.bind('<Enter>',hoveredC)
h_toChecklist_button.bind('<Leave>',unhoveredC)
h_toMental_button=Button(window,command=lambda:switchScreen('h','m'),image=h_mental_icon)
h_toMental_button.bind('<Enter>',hoveredM)
h_toMental_button.bind('<Leave>',unhoveredM)
h_toSettings_button=Button(window,command=lambda:switchScreen('h','set'),image=h_settings_icon)
h_toSettings_button.bind('<Enter>',hoveredSet)
h_toSettings_button.bind('<Leave>',unhoveredSet)



h_feedback_textbox=Text(window,font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=2,relief="solid")
h_feedback_textbox.tag_configure("center",justify="center")
h_feedback_textbox.insert("1.0", '')
h_feedback_textbox.tag_add("center", "1.0", "end")
h_charImage_label=Label(window,image=h_charImage,borderwidth=2,relief="solid")

# SUPPORT SCREEN VARIABLES

sup_bgImage=PhotoImage(file='biw_support.png')
sup_bgImage_label=Label(window,image=h_bgImage)
sup_title_label=Label(window,text='Support',borderwidth=2,relief="ridge",font=("Comic Sans MS",20))
sup_toHome_button=Button(window,command=lambda:switchScreen("sup","h"),image=home_icon)
sup_toSettings_button=Button(window,command=lambda:switchScreen("sup","set"),image=settings_icon)
sup_supports_listbox = Listbox(window, font=("Comic Sans MS", 15))
sup_supports_listbox.bind("<ButtonRelease-1>",call)
sup_add_button = Button(window,text="+",font=("Arial",80))
sup_add_button.bind("<Button-1>",addContact)

# PHYSICAL HEALTH SCREEN VARIABLES

p_bgImage=PhotoImage(file='biw_physical.png')
p_bgImage_label=Label(window,image=p_bgImage)
p_title_label=Label(window,text='Physical Health',borderwidth=2,relief="ridge",font=("Comic Sans MS",20))
p_toHome_button=Button(window,command=lambda:switchScreen('p','h'),image=home_icon)
p_toSettings_button=Button(window,command=lambda:switchScreen('p','set'),image=settings_icon)
p_widget_label=Label(window,borderwidth=2,relief="ridge")
p_calories_label=Label(window,text="Calories",font=("Comic Sans MS",12))
p_calories_bars=[Label(window,bg='#fb9938'),Label(window,bg='#fb9938'),Label(window,bg='#fb9938'),Label(window,bg='#fb9938'),Label(window,bg='#fb9938'),Label(window,bg='#fb9938'),Label(window,bg='#fb9938')]
p_calories_vals=[1541,1577,1945,935,1424,1674,1635]
p_vert_bar=Label(window,borderwidth=2,relief="solid")
p_hori_bar=Label(window,borderwidth=2,relief="solid")
p_max_numg=Label(window,text=findMaxCal())
p_mid_numg=Label(window,text=str(int(findMaxCal())//2))
p_days_label=Label(window,font=("Comic Sans MS",8),text='Sun          Mon          Tues        Wed        Thurs         Fri           Sat  ')
p_rec_label1=Label(window,bg='indianred',borderwidth=2,relief="ridge")
p_rec_label2=Label(window,bg='salmon',borderwidth=2,relief="ridge")
p_rec_label3=Label(window,bg='yellow',borderwidth=2,relief="ridge")
p_recImage1=PhotoImage(file='biw_pDrink.png')
p_recImage1_label=Label(window,image=p_recImage1,borderwidth=2,relief="ridge")
p_recImage2=PhotoImage(file='biw_pGym.png')
p_recImage2_label=Label(window,image=p_recImage2,borderwidth=2,relief="ridge")
p_recImage3=PhotoImage(file='biw_pRun.png')
p_recImage3_label=Label(window,image=p_recImage3,borderwidth=2,relief="ridge")
p_rec_text1=Label(window,font=("Comic Sans MS",14,'bold'),text='It\'s always tea time!')
p_rec_text2=Label(window,font=("Comic Sans MS",14,'bold'),text='Alice in Gymland!')
p_rec_text3=Label(window,font=("Comic Sans MS",14,'bold'),text='Can\'t be late!')
p_rec_desc1=Text(window,font=("Comic Sans MS",10))
p_rec_desc2=Text(window,font=("Comic Sans MS",10))
p_rec_desc3=Text(window,font=("Comic Sans MS",10))
p_rec_button1=Button(window,borderwidth=2,relief="solid",text='>',font=("Comic Sans MS",10),command=lambda:extLink('pDrink'))
p_rec_button2=Button(window,borderwidth=2,relief="solid",text='>',font=("Comic Sans MS",10),command=lambda:extLink('pGym'))
p_rec_button3=Button(window,borderwidth=2,relief="solid",text='>',font=("Comic Sans MS",10),command=lambda:extLink('pRun'))
# Starts the textboxes early... for good reasons
p_rec_desc1.place(x=115,y=305,width=225,height=44)
p_rec_desc1.insert("1.0", "Drinking water is important!\n")
p_rec_desc1.insert("2.0", "Click the arrow to learn more.")
p_rec_desc2.place(x=115,y=415,width=225,height=44)
p_rec_desc2.insert("1.0", "Exercise? i sai extra fries\n")
p_rec_desc2.insert("2.0", "Click the arrow to learn more.")
p_rec_desc3.place(x=115,y=525,width=225,height=44)
p_rec_desc3.insert("1.0", "Any form of cardio is good cardio.\n")
p_rec_desc3.insert("2.0", "Click the arrow to learn more.")
p_rec_desc1.config(state=DISABLED)
p_rec_desc2.config(state=DISABLED)
p_rec_desc3.config(state=DISABLED)
p_rec_desc1.place_forget()
p_rec_desc2.place_forget()
p_rec_desc3.place_forget()

# CHECKLIST SCREEN VARIABLES

c_bgImage=PhotoImage(file='biw_checklist.png')
c_bgImage_label=Label(window,image=h_bgImage)
c_title_label=Label(window,text='Checklist',borderwidth=2,relief="ridge",font=("Comic Sans MS",20))
c_toHome_button=Button(window,command=lambda:switchScreen("c","h"),image=home_icon)
c_toSettings_button=Button(window,command=lambda:switchScreen("c","set"),image=settings_icon)
c_incomp_label = Label(window,font=("Comic Sans MS", 30),text='Incomplete',borderwidth=2,relief="solid")
c_incomp_listbox = Listbox(window, font=("Comic Sans MS", 22))
#for i in range(1,9):
#    c_incomp_listbox.insert(i,"◻    Task#"+str(i))
c_incomp_listbox.bind("<Button-1>",completeTask)
c_comp_label = Label(window,font=("Comic Sans MS", 30),text='Completed',borderwidth=2,relief="solid")
c_comp_listbox = Listbox(window, font=("Comic Sans MS", 22))
#for i in range(1,5):
#    c_comp_listbox.insert(i,"🗹    Task#"+str(i))
c_comp_listbox.bind("<Button-1>",undoTask)

# MENTAL HEALTH SCREEN VARIABLES

m_bgImage=PhotoImage(file='biw_mental.png')
m_bgImage_label=Label(window,image=m_bgImage)
m_title_label=Label(window,text='Mental Health',borderwidth=2,relief="ridge",font=("Comic Sans MS",20))
m_toHome_button=Button(window,command=lambda:switchScreen('m','h'),image=home_icon)
m_toSettings_button=Button(window,command=lambda:switchScreen('m','set'),image=settings_icon)
m_widget_label=Label(window,borderwidth=2,relief="ridge")
m_hrs_label=Label(window,text="Hours Slept",font=("Comic Sans MS",12))
m_hrs_bars=[Label(window,bg='#3630ff'),Label(window,bg='#3630ff'),Label(window,bg='#3630ff'),Label(window,bg='#3630ff'),Label(window,bg='#3630ff'),Label(window,bg='#3630ff'),Label(window,bg='#3630ff')]
m_hrs_vals=[6,7,8,8,6,8,10]
m_vert_bar=Label(window,borderwidth=2,relief="solid")
m_hori_bar=Label(window,borderwidth=2,relief="solid")
m_max_numg=Label(window,text=findMaxHr())
m_mid_numg=Label(window,text=str(int(findMaxHr())//2))
m_days_label=Label(window,font=("Comic Sans MS",8),text='Sun          Mon          Tues        Wed        Thurs         Fri           Sat  ')
m_rec_label1=Label(window,bg='purple',borderwidth=2,relief="ridge")
m_rec_label2=Label(window,bg='blue',borderwidth=2,relief="ridge")
m_rec_label3=Label(window,bg='turquoise',borderwidth=2,relief="ridge")
m_recImage1=PhotoImage(file='biw_mSleep.png')
m_recImage1_label=Label(window,image=p_recImage1,borderwidth=2,relief="ridge")
m_recImage2=PhotoImage(file='biw_mMed.png')
m_recImage2_label=Label(window,image=p_recImage2,borderwidth=2,relief="ridge")
m_recImage3=PhotoImage(file='biw_mTalk.png')
m_recImage3_label=Label(window,image=p_recImage3,borderwidth=2,relief="ridge")
m_rec_text1=Label(window,font=("Comic Sans MS",11,'bold'),text='Even this illogical cat sleeps!')
m_rec_text2=Label(window,font=("Comic Sans MS",11,'bold'),text='Thinking Through the Chaos')
m_rec_text3=Label(window,font=("Comic Sans MS",11,'bold'),text='Talking down the rabbit hole!')
m_rec_desc1=Text(window,font=("Comic Sans MS",10))
m_rec_desc2=Text(window,font=("Comic Sans MS",10))
m_rec_desc3=Text(window,font=("Comic Sans MS",10))
m_rec_button1=Button(window,borderwidth=2,relief="solid",text='>',font=("Comic Sans MS",10),command=lambda:extLink('mSleep'))
m_rec_button2=Button(window,borderwidth=2,relief="solid",text='>',font=("Comic Sans MS",10),command=lambda:extLink('mMed'))
m_rec_button3=Button(window,borderwidth=2,relief="solid",text='>',font=("Comic Sans MS",10),command=lambda:extLink('mTalk'))
# Starts the textboxes early... for good reasons
m_rec_desc1.place(x=115,y=305,width=225,height=44)
m_rec_desc1.insert("1.0", "Always get a full night's rest.\n")
m_rec_desc1.insert("2.0", "Click the arrow to learn more.")
m_rec_desc2.place(x=115,y=415,width=225,height=44)
m_rec_desc2.insert("1.0", "Sometimes, you just need to relax.\n")
m_rec_desc2.insert("2.0", "Click the arrow to learn more.")
m_rec_desc3.place(x=115,y=525,width=225,height=44)
m_rec_desc3.insert("1.0", "Keep bonds with friends and family.\n")
m_rec_desc3.insert("2.0", "Click the arrow to learn more.")
m_rec_desc1.config(state=DISABLED)
m_rec_desc2.config(state=DISABLED)
m_rec_desc3.config(state=DISABLED)
m_rec_desc1.place_forget()
m_rec_desc2.place_forget()
m_rec_desc3.place_forget()

# SETTINGS SCREEN VARIABLES

set_bgImage=PhotoImage(file='biw_settings.png')
set_bgImage_label=Label(window,image=set_bgImage)
set_title_label=Label(window,text='Settings and Preferences',borderwidth=2,relief="ridge",font=("Comic Sans MS",20))
set_toHome_button=Button(window,command=lambda:switchScreen("set","h"),image=home_icon)
set_age_label=Label(window,text='Age: ',font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=2,relief="solid")
set_age_variable=StringVar(window)
set_age_variable.set("10-19")
set_age_dropdown=OptionMenu(window,set_age_variable,"10-19","20-29","30-39","40-49","50-59","60+")
set_age_dropdown.config(font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=5,relief="solid")
set_age_variable.trace_add("write", updateSettings)
set_age_entry=Entry(window,textvariable=set_age_variable)
set_gender_label=Label(window,text='Gender: ',font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=2,relief="solid")
set_gender_variable=StringVar(window)
set_gender_variable.set("Male")
set_gender_dropdown=OptionMenu(window,set_gender_variable,"Male","Female","Other","Rather Not Say")
set_gender_dropdown.config(font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=5,relief="solid")
set_gender_variable.trace_add("write", updateSettings)
set_gender_entry=Entry(window,textvariable=set_gender_variable)
set_height_label=Label(window,text='Height: ',font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=2,relief="solid")
set_height_variable=StringVar(window)
set_height_variable.set("4'0\"-4'6\"")
set_height_dropdown=OptionMenu(window,set_height_variable,"4'0\"-4'5\"","4'6\"-4'11\"","5'0\"-5'5\"","5'6\"-5'11\"","6'0+")
set_height_variable.trace_add("write", updateSettings)
set_height_entry=Entry(window,textvariable=set_height_variable)
set_height_dropdown.config(font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=5,relief="solid")
set_weight_label=Label(window,text='Weight (lbs.): ',font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=2,relief="solid")
set_weight_variable=StringVar(window)
set_weight_variable.set("75-100")
set_weight_dropdown=OptionMenu(window,set_weight_variable,"75-100","101-125","126-150","151-175","175-200","200+")
set_weight_dropdown.config(font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=5,relief="solid")
set_weight_variable.trace_add("write", updateSettings)
set_weight_entry=Entry(window,textvariable=set_weight_variable)
set_difficulty_label=Label(window,text='Difficulty: ',font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=2,relief="solid")
set_difficulty_variable=StringVar(window)
set_difficulty_variable.set("Easy")
set_difficulty_dropdown=OptionMenu(window,set_difficulty_variable,"Easy","Medium","Hard")
set_difficulty_dropdown.config(font=("Comic Sans MS",20),fg="black",bg="white",borderwidth=5,relief="solid")
set_difficulty_variable.trace_add("write", updateSettings)
set_difficulty_entry=Entry(window,textvariable=set_difficulty_variable)

# Starts it all
randomGenerateContacts()
generateTasks()
updateLists()
showScreen('h')

window.mainloop()